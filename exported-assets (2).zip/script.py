
# Let me compile all the real-world deployment information for AgroSakha

# Complete list of villages in Harda District
harda_villages = [
    "Abagaon Khurd", "Agra", "Alanpur", "Amarapur", "Baghadiya", "Baidagaon", 
    "Bairagarh", "Balagaon", "Bamhangaon", "Barkhedi", "Beed", "Bhamaner", 
    "Bhatparetiya", "Bhonkhedi", "Bhunnas", "Birjakhedi", "Bundra", "Chhurikhal",
    "Dagawan Balwant", "Dagawan Neema", "Dagawan Shankar", "Dedala Damami", 
    "Dhurgada", "Dhurranikheda", "Dinkarpura", "Dudhakatch Khurd", "Duliya",
    "Gadgi", "Gahal", "Gangla", "Ghoghda", "Guthaniya", "Harda Khas", "Hardakhurd",
    "Jamuniya", "Jhadpa", "Jhallar", "Jhiri", "Jhundgaon", "Jijgaon Kalan",
    "Jijgaonkhurd", "Kadola Ubari", "Kakariya", "Kamtada", "Kanarda", "Kelanpur",
    "Khama", "Kharpa", "Khedi Mahmudabad", "Khedi Vinayak", "Khedibondru",
    "Kosaghati", "Kotalya Khedi", "Kukrawad", "Kul Harda", "Kunjpura", "Lalmati",
    "Lalpura", "Magardha", "Majli", "Malor", "Masangaon", "Mohanpur", "Nahadiya",
    "Nahal Kheda", "Nakwada", "Padwan", "Pahatgaon", "Palasner", "Pidgaon",
    "Piplya", "Rahta Khurd", "Raisalpur", "Ranhai Kalan", "Ranya Khedi",
    "Richhadiya", "Rolgaon", "Rupiparetiya", "Samardha", "Sirkamba", "Sonkhedi",
    "Sukhras", "Sultanpur", "Uda"
]

# Harda district coordinates (approximate center)
harda_coords = {
    "latitude": 22.344,
    "longitude": 77.095,
    "district": "Harda",
    "state": "Madhya Pradesh"
}

# Crops grown in Harda region
harda_crops = [
    "Wheat (Gehu)",
    "Soybean (Soyabeen)", 
    "Cotton (Kapas)",
    "Gram/Chickpea (Chana)",
    "Mustard (Sarson)",
    "Maize (Makka)",
    "Pigeon Pea (Arhar/Tur)"
]

print(f"Total villages in Harda Tehsil: {len(harda_villages)}")
print(f"Harda District Center: Lat {harda_coords['latitude']}, Lon {harda_coords['longitude']}")
print(f"Major crops: {', '.join(harda_crops)}")
